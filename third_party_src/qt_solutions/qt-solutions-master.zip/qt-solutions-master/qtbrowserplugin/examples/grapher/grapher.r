#define SystemSevenOrLater 1

#include <Carbon/Carbon.r>

resource 'STR#' (127)
{{
"A graphing plugin!"
}};

resource 'STR#' (128)
{{
"application/x-graphable",
""
}};

resource 'STR#' (126)
{{
"Plugin for demonstration"
}};
